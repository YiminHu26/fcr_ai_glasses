## 项目概述
- **名称**: 二维码识别工作流
- **功能**: 输入图片URL，通过webp编码解码预处理后，采用zxing-cpp+OpenCV+图像预处理的多策略级联识别二维码，直接输出识别到的JSON字典内容。API仅需传入图片url，file_type固定为image。

### 节点清单
| 节点名 | 文件位置 | 类型 | 功能描述 | 分支逻辑 | 配置文件 |
|-------|---------|------|---------|---------|---------|
| webp_codec | `nodes/webp_codec_node.py` | task | 将JPEG图片通过webp编码解码处理，输出PNG格式bytes | - | - |
| barcode_detect | `nodes/barcode_detect_node.py` | task | 多策略级联识别二维码：A层zxing-cpp(主，鲁棒性强) → C层OpenCV QRCodeDetector → 增强层(灰度/二值化/放大)重试 | - | - |
| json_extract | `nodes/json_extract_node.py` | task | 取第一个二维码识别结果的data字段(JSON文本)直接输出 | - | - |

**类型说明**: task(task节点) / agent(大模型) / condition(条件分支) / looparray(列表循环) / loopcond(条件循环)

## 子图清单
无子图

## 技能使用
- 依赖包：OpenCV(opencv-python-headless)、Pillow、zxing-cpp（无系统依赖，用于真实照片二维码识别）
