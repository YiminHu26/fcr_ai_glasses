"""
二维码识别工作流 - 主图编排
流程：输入JPEG图片 → webp编解码处理 → 二维码识别 → JSON文本输出
"""
from langgraph.graph import StateGraph, END
from graphs.state import (
    GlobalState,
    GraphInput,
    GraphOutput,
)
from graphs.nodes.webp_codec_node import webp_codec_node
from graphs.nodes.barcode_detect_node import barcode_detect_node
from graphs.nodes.json_extract_node import json_extract_node

# 创建状态图，指定全局状态、入参和出参
builder = StateGraph(GlobalState, input_schema=GraphInput, output_schema=GraphOutput)

# 添加节点
builder.add_node("webp_codec", webp_codec_node)
builder.add_node("barcode_detect", barcode_detect_node)
builder.add_node("json_extract", json_extract_node)

# 设置入口点
builder.set_entry_point("webp_codec")

# 添加边：webp编解码 → 二维码识别 → JSON文本输出 → 结束
builder.add_edge("webp_codec", "barcode_detect")
builder.add_edge("barcode_detect", "json_extract")
builder.add_edge("json_extract", END)

# 编译图
main_graph = builder.compile()
