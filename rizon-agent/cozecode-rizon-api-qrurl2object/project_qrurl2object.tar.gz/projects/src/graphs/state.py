"""
二维码识别工作流 - 状态定义
"""
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from utils.file.file import File


class GlobalState(BaseModel):
    """全局状态定义"""
    image_url: str = Field(..., description="输入的RGB JPEG图片URL")
    image_png_bytes: Optional[bytes] = Field(default=None, description="webp编解码后的PNG图像bytes")
    qr_results: List[Dict[str, Any]] = Field(default=[], description="二维码识别结果列表，每个元素包含data和points")
    qr_count: int = Field(default=0, description="识别到的二维码数量")
    json_output: Dict[str, Any] = Field(default={}, description="识别出的二维码内容(字典形式的JSON)")


class GraphInput(BaseModel):
    """工作流输入"""
    image_url: str = Field(..., description="输入的RGB JPEG图片URL")


class GraphOutput(BaseModel):
    """工作流输出"""
    qr_results: List[Dict[str, Any]] = Field(default=[], description="二维码识别结果列表")
    qr_count: int = Field(default=0, description="识别到的二维码数量")
    json_output: Dict[str, Any] = Field(default={}, description="识别出的二维码内容(字典形式的JSON)")


# ========== webp编解码节点 ==========
class WebpCodecInput(BaseModel):
    """webp编解码节点输入"""
    image_url: str = Field(..., description="输入的RGB JPEG图片URL")


class WebpCodecOutput(BaseModel):
    """webp编解码节点输出"""
    image_png_bytes: bytes = Field(..., description="经过webp编码解码后重新编码为PNG格式的图像bytes")


# ========== 二维码识别节点 ==========
class BarcodeDetectInput(BaseModel):
    """二维码识别节点输入"""
    image_png_bytes: bytes = Field(..., description="待检测的PNG格式图像bytes")


class BarcodeDetectOutput(BaseModel):
    """二维码识别节点输出"""
    qr_results: List[Dict[str, Any]] = Field(default=[], description="二维码识别结果列表，每个元素包含data(解码内容)和points(四个顶点坐标)")
    qr_count: int = Field(default=0, description="识别到的二维码数量")


# ========== JSON提取节点 ==========
class JsonExtractInput(BaseModel):
    """JSON提取节点输入"""
    qr_results: List[Dict[str, Any]] = Field(default=[], description="二维码识别结果列表")


class JsonExtractOutput(BaseModel):
    """JSON提取节点输出"""
    json_output: Dict[str, Any] = Field(default={}, description="识别出的二维码内容(字典形式的JSON)")