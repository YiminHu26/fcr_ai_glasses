"""
webp编解码节点：将JPEG图片通过webp编码解码处理
"""
import io
import numpy as np
from PIL import Image
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.file.file import File, FileOps
from graphs.state import WebpCodecInput, WebpCodecOutput


def webp_codec_node(state: WebpCodecInput, config: RunnableConfig, runtime: Runtime[Context]) -> WebpCodecOutput:
    """
    title: webp编解码处理
    desc: 将输入的RGB JPEG图片进行webp编码，再从webp解码回RGB图像，最终输出PNG格式的图像bytes
    """
    ctx = runtime.context

    # 0. 由图片URL构造File对象，固定类型为image
    image_file: File = File(url=state.image_url, file_type="image")

    # 1. 读取输入图片的原始bytes
    image_bytes: bytes = FileOps.read_bytes(image_file)
    if not image_bytes:
        raise ValueError("读取图片数据为空")

    # 2. 使用Pillow打开JPEG图片并转为RGB模式
    pil_img: Image.Image = Image.open(io.BytesIO(image_bytes)).convert("RGB")

    # 3. 将RGB图像编码为webp格式（使用最高质量，避免对真实照片二次损失画质）
    webp_buffer = io.BytesIO()
    pil_img.save(webp_buffer, format="WEBP", quality=100)
    webp_data: bytes = webp_buffer.getvalue()

    # 4. 从webp格式解码回PIL Image
    decoded_img: Image.Image = Image.open(io.BytesIO(webp_data)).convert("RGB")

    # 5. 将解码后的图像编码为PNG格式bytes，便于下游节点使用
    png_buffer = io.BytesIO()
    decoded_img.save(png_buffer, format="PNG")
    png_bytes: bytes = png_buffer.getvalue()

    return WebpCodecOutput(image_png_bytes=png_bytes)
