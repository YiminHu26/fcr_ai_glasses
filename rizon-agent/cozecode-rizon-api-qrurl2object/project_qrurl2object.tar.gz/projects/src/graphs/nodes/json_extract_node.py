"""
JSON提取节点：将二维码识别结果中的JSON内容解析为字典输出
"""
import json
from typing import List, Dict, Any
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import JsonExtractInput, JsonExtractOutput


def json_extract_node(state: JsonExtractInput, config: RunnableConfig, runtime: Runtime[Context]) -> JsonExtractOutput:
    """
    title: JSON字段提取
    desc: 取第一个二维码识别结果中的data字段(JSON文本)，解析为字典形式输出
    """
    ctx = runtime.context

    json_output: Dict[str, Any] = {}

    if state.qr_results and len(state.qr_results) > 0:
        first_result: Dict[str, Any] = state.qr_results[0]
        data = first_result.get("data", "")
        if data:
            try:
                parsed: Any = json.loads(data)
                if isinstance(parsed, dict):
                    json_output = parsed
                else:
                    # 解析结果不是字典时，包装为字典
                    json_output = {"json_content": parsed}
            except (json.JSONDecodeError, TypeError):
                # 无法解析为JSON时，原样放入字典
                json_output = {"text": str(data)}

    return JsonExtractOutput(json_output=json_output)