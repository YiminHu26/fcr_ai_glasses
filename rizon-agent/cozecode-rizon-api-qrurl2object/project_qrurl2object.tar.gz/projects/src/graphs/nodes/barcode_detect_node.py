"""
二维码识别节点：多策略级联识别
- A层：zxing-cpp（无系统依赖、鲁棒性最强，擅长真实拍摄/模糊/小尺寸/透视/低对比度二维码）
- C层：OpenCV QRCodeDetector 快速兜底
- 增强层：图像预处理（灰度/二值化/放大）后再尝试
"""
import io
import logging
import cv2
import numpy as np
from PIL import Image
from typing import List, Dict, Any
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
import zxingcpp
from graphs.state import BarcodeDetectInput, BarcodeDetectOutput

logger = logging.getLogger(__name__)


def _try_zxing(img: np.ndarray) -> List[Dict[str, Any]]:
    """zxing-cpp 主识别层：返回识别结果列表"""
    results: List[Dict[str, Any]] = []
    try:
        barcodes = zxingcpp.read_barcodes(img)
        for b in barcodes:
            text = getattr(b, "text", "")
            if not text:
                continue
            pts: List[List[float]] = []
            pos = getattr(b, "position", None)
            if pos is not None:
                try:
                    pts = [
                        [float(pos.top_left.x), float(pos.top_left.y)],
                        [float(pos.top_right.x), float(pos.top_right.y)],
                        [float(pos.bottom_right.x), float(pos.bottom_right.y)],
                        [float(pos.bottom_left.x), float(pos.bottom_left.y)],
                    ]
                except Exception:
                    pts = []
            results.append({
                "data": str(text),
                "points": pts,
                "format": str(getattr(b, "format", ""))
            })
    except Exception as e:
        logger.warning("zxing-cpp 识别异常: %s", e)
    return results


def _try_opencv(bgr_img: np.ndarray) -> List[Dict[str, Any]]:
    """OpenCV 快速兜底层"""
    results: List[Dict[str, Any]] = []
    detector = cv2.QRCodeDetector()
    # OpenCV 4.13 detectAndDecodeMulti 返回 (retval, decoded_infos, points, straight_qrcodes)
    try:
        multi_result = detector.detectAndDecodeMulti(bgr_img)
        retval_multi: bool = multi_result[0]
        decoded_infos = multi_result[1] if len(multi_result) > 1 else ()
        points_multi = multi_result[2] if len(multi_result) > 2 else None
        if retval_multi and decoded_infos:
            for i, info in enumerate(decoded_infos):
                if info:
                    item: Dict[str, Any] = {"data": str(info), "points": [], "format": "QRCode"}
                    if points_multi is not None and i < len(points_multi):
                        p = points_multi[i]
                        if p is not None and hasattr(p, "tolist"):
                            item["points"] = [list(map(float, pt)) for pt in p.tolist()]
                    results.append(item)
    except Exception as e:
        logger.warning("OpenCV 多码检测异常: %s", e)

    if not results:
        # OpenCV 4.13 detectAndDecode 返回 (decoded_info, points, straight_qrcode)
        try:
            single_result = detector.detectAndDecode(bgr_img)
            decoded_info = single_result[0] if len(single_result) > 0 else ""
            if decoded_info:
                item: Dict[str, Any] = {"data": str(decoded_info), "points": [], "format": "QRCode"}
                pts_single = single_result[1] if len(single_result) > 1 else None
                if pts_single is not None and hasattr(pts_single, "tolist"):
                    item["points"] = [list(map(float, pt)) for pt in pts_single.tolist()]
                results.append(item)
        except Exception as e:
            logger.warning("OpenCV 单码检测异常: %s", e)
    return results


def _preprocess_variants(img: np.ndarray) -> List[np.ndarray]:
    """生成多种预处理增强版本，用于强化识别小/模糊/低对比度二维码"""
    variants: List[np.ndarray] = []
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    variants.append(gray)
    # 自适应阈值二值化
    try:
        binary = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
        )
        variants.append(binary)
    except Exception:
        pass
    # 放大2x
    try:
        up = cv2.resize(img, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
        variants.append(up)
        up_gray = cv2.resize(gray, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
        variants.append(up_gray)
    except Exception:
        pass
    return variants


def barcode_detect_node(state: BarcodeDetectInput, config: RunnableConfig, runtime: Runtime[Context]) -> BarcodeDetectOutput:
    """
    title: 二维码识别（多策略级联）
    desc: 采用 zxing-cpp + OpenCV + 图像预处理的级联识别策略，大幅提升对真实拍摄、模糊、小尺寸、倾斜、低对比度二维码的识别成功率
    integrations: zxingcpp
    """
    ctx = runtime.context

    # 1. 从PNG bytes解码为PIL Image，再转为numpy array (RGB)
    pil_img: Image.Image = Image.open(io.BytesIO(state.image_png_bytes)).convert("RGB")
    rgb_array: np.ndarray = np.array(pil_img)

    # 2. RGB转BGR（OpenCV使用BGR格式）
    bgr_array: np.ndarray = cv2.cvtColor(rgb_array, cv2.COLOR_RGB2BGR)

    results: List[Dict[str, Any]] = []

    # A层：zxing-cpp（主识别，鲁棒性最强）
    results = _try_zxing(rgb_array)

    # C层：OpenCV 快速兜底
    if not results:
        results = _try_opencv(bgr_array)

    # 增强层：图像预处理后再尝试
    if not results:
        for variant in _preprocess_variants(rgb_array):
            candidate = _try_zxing(variant)
            if candidate:
                results = candidate
                break

    return BarcodeDetectOutput(
        qr_results=results,
        qr_count=len(results)
    )