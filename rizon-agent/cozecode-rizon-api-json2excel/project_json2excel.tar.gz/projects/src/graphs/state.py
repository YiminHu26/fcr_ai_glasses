"""
JSON to Excel 工作流状态定义
"""
from typing import List, Dict, Optional, Any
from pydantic import BaseModel, Field
from utils.file.file import File


class GlobalState(BaseModel):
    """全局状态定义"""
    json_data: str = Field(default="", description="输入的JSON字符串")
    parsed_data: List[Dict[str, Any]] = Field(default=[], description="解析后的JSON数据列表")
    excel_file_url: str = Field(default="", description="生成的Excel文件对象存储下载URL")


class GraphInput(BaseModel):
    """工作流的输入"""
    json_data: str = Field(..., description="输入的JSON字符串，格式为JSON数组")


class GraphOutput(BaseModel):
    """工作流的输出"""
    excel_file_url: str = Field(..., description="生成的Excel文件对象存储下载URL")
    row_count: int = Field(default=0, description="Excel中的数据行数")


class ParseJsonInput(BaseModel):
    """JSON解析节点的输入"""
    json_data: str = Field(..., description="输入的JSON字符串")


class ParseJsonOutput(BaseModel):
    """JSON解析节点的输出"""
    parsed_data: List[Dict[str, Any]] = Field(..., description="解析后的JSON数据列表")
    columns: List[str] = Field(default=[], description="所有列名列表")


class GenerateExcelInput(BaseModel):
    """Excel生成节点的输入"""
    parsed_data: List[Dict[str, Any]] = Field(..., description="解析后的JSON数据列表")
    columns: List[str] = Field(default=[], description="所有列名列表")


class GenerateExcelOutput(BaseModel):
    """Excel生成节点的输出"""
    excel_file_url: str = Field(..., description="生成的Excel文件对象存储下载URL")
    row_count: int = Field(default=0, description="Excel中的数据行数")
