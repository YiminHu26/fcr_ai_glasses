"""
JSON to Excel 工作流主图编排
"""
from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime

from graphs.state import GlobalState, GraphInput, GraphOutput
from graphs.nodes.parse_json_node import parse_json_node
from graphs.nodes.generate_excel_node import generate_excel_node

# 创建状态图，指定入参和出参
builder = StateGraph(GlobalState, input_schema=GraphInput, output_schema=GraphOutput)

# 添加节点
builder.add_node("parse_json", parse_json_node)
builder.add_node("generate_excel", generate_excel_node)

# 设置入口点
builder.set_entry_point("parse_json")

# 添加边：解析JSON -> 生成Excel
builder.add_edge("parse_json", "generate_excel")

# 生成Excel -> 结束
builder.add_edge("generate_excel", END)

# 编译图
main_graph = builder.compile()
