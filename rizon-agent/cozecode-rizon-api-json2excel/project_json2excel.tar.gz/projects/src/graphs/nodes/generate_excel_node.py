"""
Excel生成节点 - 将解析后的JSON数据生成Excel文件，上传到对象存储并返回下载URL
"""
import os
import logging
import time
from typing import List, Dict, Any

import pandas as pd
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_dev_sdk.s3 import S3SyncStorage
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import GenerateExcelInput, GenerateExcelOutput

logger = logging.getLogger(__name__)


def generate_excel_node(
    state: GenerateExcelInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> GenerateExcelOutput:
    """
    title: 生成Excel文件
    desc: 将解析后的JSON数据列表转换为Excel文件，上传到对象存储并返回下载URL
    """
    ctx = runtime.context

    parsed_data: List[Dict[str, Any]] = state.parsed_data
    columns: List[str] = state.columns

    if not parsed_data:
        raise ValueError("没有数据可生成Excel")

    # 使用pandas创建DataFrame
    df = pd.DataFrame(parsed_data)

    # 按JSON中出现的列顺序排列（parse_json节点提取的columns）
    if columns:
        existing_columns: List[str] = [col for col in columns if col in df.columns]
        extra_columns: List[str] = [col for col in df.columns if col not in columns]
        ordered_columns: List[str] = existing_columns + extra_columns
        df = df[ordered_columns]

    # 生成带时间戳的文件名，避免冲突
    timestamp = int(time.time())
    file_name = f"inspection_report_{timestamp}.xlsx"

    # 先写入 /tmp 目录（线上环境可写）
    tmp_path = os.path.join("/tmp", file_name)
    df.to_excel(tmp_path, index=False, engine="openpyxl")

    row_count = len(df)
    logger.info(f"Excel文件已生成到临时目录: {tmp_path}, 共{row_count}行数据")

    # 上传到对象存储
    storage = S3SyncStorage(
        endpoint_url=os.getenv("COZE_BUCKET_ENDPOINT_URL"),
        access_key="",
        secret_key="",
        bucket_name=os.getenv("COZE_BUCKET_NAME"),
        region="cn-beijing",
    )

    with open(tmp_path, "rb") as f:
        file_key = storage.stream_upload_file(
            fileobj=f,
            file_name=file_name,
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    logger.info(f"Excel文件已上传到对象存储, key: {file_key}")

    # 生成签名URL（有效期24小时）
    download_url = storage.generate_presigned_url(
        key=file_key,
        expire_time=86400,
    )

    # 清理临时文件
    try:
        os.remove(tmp_path)
    except OSError:
        pass

    logger.info(f"Excel文件下载URL已生成: {download_url}")

    return GenerateExcelOutput(excel_file_url=download_url, row_count=row_count)
