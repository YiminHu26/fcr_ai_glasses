"""
JSON解析节点 - 将JSON字符串解析为结构化数据
"""
import os
import json
import logging
from typing import List, Dict, Any

from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import ParseJsonInput, ParseJsonOutput

logger = logging.getLogger(__name__)


def parse_json_node(
    state: ParseJsonInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> ParseJsonOutput:
    """
    title: JSON解析
    desc: 将输入的JSON字符串解析为结构化的数据列表，并提取所有列名
    """
    ctx = runtime.context

    json_str: str = state.json_data
    if not json_str or not isinstance(json_str, str):
        raise ValueError("输入的JSON数据为空或格式不正确")

    json_str = json_str.strip()

    try:
        parsed_data: List[Dict[str, Any]] = json.loads(json_str)
    except json.JSONDecodeError as e:
        logger.error(f"JSON解析失败: {e}")
        raise ValueError(f"JSON解析失败，请检查格式是否正确: {e}")

    if not isinstance(parsed_data, list):
        raise ValueError("JSON数据必须是数组格式")

    # 提取所有列名（保持顺序，去重）
    columns_set: set = set()
    columns: List[str] = []
    for item in parsed_data:
        if isinstance(item, dict):
            for key in item.keys():
                if key not in columns_set:
                    columns_set.add(key)
                    columns.append(key)

    logger.info(f"JSON解析成功，共{len(parsed_data)}条记录，{len(columns)}个字段")

    return ParseJsonOutput(parsed_data=parsed_data, columns=columns)
