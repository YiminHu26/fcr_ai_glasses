## 项目概述
- **名称**: JSON to Excel 工作流
- **功能**: 将JSON数组字符串解析并转换为Excel文件，上传到对象存储返回下载URL

### 节点清单
| 节点名 | 文件位置 | 类型 | 功能描述 | 分支逻辑 | 配置文件 |
|-------|---------|------|---------|---------|---------|
| parse_json | `nodes/parse_json_node.py` | task | 解析JSON字符串为结构化数据列表 | - | - |
| generate_excel | `nodes/generate_excel_node.py` | task | 将数据生成Excel文件，上传对象存储返回下载URL | - | - |

**类型说明**: task(task节点) / agent(大模型) / condition(条件分支) / looparray(列表循环) / loopcond(条件循环)

## 子图清单
无

## 技能使用
- 节点`generate_excel`使用对象存储技能（coze-coding-dev-sdk S3SyncStorage）上传Excel文件并生成下载URL
